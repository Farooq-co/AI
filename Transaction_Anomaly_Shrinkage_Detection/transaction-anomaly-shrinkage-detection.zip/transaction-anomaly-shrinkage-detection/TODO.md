- [x] Review current dashboard routing/template data wiring

- [ ] Fix `app/routes/dashboard.py` route decorators (remove invalid empty route)
- [ ] Fix dashboard chart variables to pass Python lists (remove `json.dumps`)
- [x] Fix `templates/dashboard.html` to render chart variables with `|tojson`

- [x] Quick python compile check
- [ ] Run server and sanity-check `/dashboard/` rendering


